﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DomainWorkers.RDAP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RdapController : ControllerBase
    {
        [HttpGet("{ip_address}")]
        public IActionResult Get(string ip_address)
        {
            return Ok("RDAP");
        }
    }
}
