﻿using Microsoft.AspNetCore.Mvc;

namespace DomainWorkers.GeoIP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeoIPController : ControllerBase
    {
        [HttpGet("{ip_address}")]
        public IActionResult Get(string ip_address)
        {
            return Ok("Geoip");
        }
    }
}
